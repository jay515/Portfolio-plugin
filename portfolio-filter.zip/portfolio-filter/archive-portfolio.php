<?php 

/*Archive template portfolio listing*/

get_header();

$cat_args = array(
    'order'      => 'desc',
    'hide_empty' => true,
    );
 
    $portfolio_categories = get_terms( 'portfolio_category', $cat_args );
    ?> 
    <div class="archiveportfolio-lists container">
        <ul class="tabs">
            <?php 
            $i = 1;
            foreach ($portfolio_categories as $portfolio_category) {

                $class = ($i == 1) ? "current" : "";
                 ?>
                <li data-cat="<?php echo $portfolio_category->term_id; ?>" class="tab-link <?php echo $class; ?>" data-tab="cat-<?php echo $i; ?>"><?php echo $portfolio_category->name; ?></li>
            <?php $i++;} ?>
        </ul>
        <?php 
        $j = 1;
        foreach ($portfolio_categories as $portfolio_category) {
            $args = array(
                'post_type'      => 'portfolio',
                'order'         => 'asc',
                'posts_per_page' => 4,
                'tax_query' => array(
                    array(
                        'taxonomy' => 'portfolio_category',
                        'field'    => 'slug',
                        'terms'    => $portfolio_category->name
                    )
                )   
            );
            $class = ($j == 1) ? "current" : "";
            $portfolio_lists = get_posts( $args );
            ?>
            <div id="cat-<?php echo $j; ?>" class="tab-content <?php echo $class?>">
                <div class="portfolio-lists">
                <?php 
                foreach ($portfolio_lists as $portfolio_list) {
                    $portfolio_id = $portfolio_list->ID;
                    $portfolio_img =  wp_get_attachment_url( get_post_thumbnail_id($portfolio_id), 'thumbnail' ); 

                    ?>
                    <div class="portfolio-item">
                        <a href="<?php echo get_permalink($portfolio_id); ?>"><img class="portfolio-img" src="<?php echo $portfolio_img; ?>" alt="portfolio" /></a>
                        <h4><strong><?php echo $portfolio_list->post_title ?></strong></h4>
                    </div>
                <?php } ?>
                </div>
                <div class="no-post-msg"></div>
            </div>
        <?php $j++;} ?>
        <div class="ajax-loader"><span class="pf-loader"></span></div>
        <div class="load-more-btn"><a id="load_more_btn" data-page="1" href="javascript:void(0)">Load More</a></div>
    </div>
   

<?php
get_footer();

?>