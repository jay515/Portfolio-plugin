<?php
/**
 * Plugin Name:       Portfolio Filter
 * Plugin URI:        https://example.com/plugins/the-basics/
 * Description:       Category wise portfolio filter 
 * Version:           1.0.3
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            jani jaydip 
 * Author URI:        https://author.example.com/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Update URI:        https://example.com/plugins/the-basics/
 * Text Domain:       portfolio-filter
 * Domain Path:       /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

// Plugin Root File
define( 'PORTFOLIO_PLUGIN_FILE', __FILE__ );

/**
 * Activate the plugin.
 */
function portfolio_activate() { 
    // Trigger our function that registers the custom post type plugin.
    portfolio_register_setting_page(); 
    // Clear the permalinks after the post type has been registered.
    flush_rewrite_rules(); 
}
register_activation_hook( PORTFOLIO_PLUGIN_FILE, 'portfolio_activate' );

/**
 * Deactivation hook.
 */
function portfolio_deactivate() {
    // Unregister the post type, so the rules are no longer in memory.
    remove_menu_page( 'portfolio' );
    // Clear the permalinks to remove our post type's rules from the database.
    flush_rewrite_rules();
}
register_deactivation_hook( PORTFOLIO_PLUGIN_FILE, 'portfolio_deactivate' );





function portfolio_admin_enqueue_scripts(){
    wp_enqueue_style('portfolio_admin_style',  plugins_url('/assets/css/portfolio-admin-style.css', __FILE__), false, '1.0.0', 'all');        
}
add_action('admin_enqueue_scripts','portfolio_admin_enqueue_scripts');

/*
 * Register the css and js
 */

function portfolio_fronted_enqueue() {

    wp_enqueue_script('jquery');

    wp_enqueue_style( 'portfolio-fronted-style', plugin_dir_url( __FILE__ ) . '/assets/css/portfolio-fronted-style.css' );

    wp_enqueue_script('matchheight', plugin_dir_url(__FILE__) . 'assets/js/matchHeight-min.js');
    
    wp_enqueue_script('portfoliocustom', plugin_dir_url(__FILE__) . 'assets/js/portfoliocustom.js');

    wp_localize_script( 'portfoliocustom', 'frontend_ajax', array( 'ajaxurl' => admin_url('admin-ajax.php') ) );

}
add_action( 'wp_enqueue_scripts', 'portfolio_fronted_enqueue');

/* Custom Post Create */
function custom_portfolio_filter_post() {
  $labels = array(
    'name'               => _x( 'Portfolio Filter', 'plural' ),
    'singular_name'      => _x( 'Portfolio Filter', 'singular' ),
    'add_new'            => _x( 'Add Portfolio', 'portfolio-filter' ),
    'add_new_item'       => __( 'Add Portfolio' ),
    'edit_item'          => __( 'Edit Portfolio' ),
    'new_item'           => __( 'New Portfolio' ),
    'all_items'          => __( 'All Portfolio' ),
    'view_item'          => __( 'View Portfolio' ),
    'search_items'       => __( 'Search Portfolio' ),
    'not_found'          => __( 'No Portfolio found' ),
    'not_found_in_trash' => __( 'No Portfolio found in the Trash' ), 
    'menu_name'          => 'Portfolio Filter'
  );
  $args = array(
    'labels'        => $labels,
    'description'   => 'Our portfolio specific data',
    'public'        => true,
    'menu_position' => 5,
    'supports'      => array('title','editor','thumbnail','author'),
    'has_archive'   => true,
  );
  register_post_type( 'portfolio', $args ); 
}
add_action( 'init', 'custom_portfolio_filter_post');

function taxonomies_portfolio_filter() {
  $labels = array(
    'name'              => _x( 'Portfolio Category', 'portfolio-filter' ),
    'singular_name'     => _x( 'Portfolio Category', 'portfolio-filter' ),
    'search_items'      => __( 'Search Portfolio Category' ),
    'all_items'         => __( 'All Portfolio Category' ),
    'parent_item'       => __( 'Parent Portfolio Category' ),
    'parent_item_colon' => __( 'Parent Portfolio Category:' ),
    'edit_item'         => __( 'Edit Portfolio Category' ), 
    'update_item'       => __( 'Update Portfolio Category' ),
    'add_new_item'      => __( 'Add New Portfolio Category' ),
    'new_item_name'     => __( 'New Portfolio Category' ),
    'menu_name'         => __( 'Portfolio Category' ),
  );
  $args = array(
    'labels' => $labels,
    'hierarchical' => true,
    'show_admin_column' => true, 
  );
  register_taxonomy( 'portfolio_category', 'portfolio', $args );
}
add_action( 'init', 'taxonomies_portfolio_filter', 0 );

/**
* Adds a submenu page under a custom post type parent.
*/
add_action('admin_menu', 'portfolio_register_setting_page');

function portfolio_register_setting_page() {
    add_submenu_page(
        'edit.php?post_type=portfolio',
        __( 'Portfolio Setting', 'portfolio-filter' ),
        __( 'Portfolio Shortcode', 'portfolio-filter' ),
        'manage_options',
        'portfolio-shortcode',
        'portfolio_setting_page_callback'
    );
}

/*
 * Admin notices
 */
add_action('admin_notices', 'portfolio_admin_notices');
function portfolio_admin_notices(){
   settings_errors();
}

//Display callback for the submenu page.e
function portfolio_setting_page_callback(){ ?>
    <div class="wrap">
        <h1><?php _e( 'Portfolio Filter settings', 'portfolio-filter' ); ?></h1>
        <form action="#" method="post">
            <div class="portfolio-form">
                <label class="portfolio-label">Form shortcode</label>
                <input class="portfolio-input" name="form_shortcode" type="text" id="form_shortcode" value="<?php echo '[portfolio-filter-lists]' ?>" readonly/>
                <button class="green-btn" onclick="copyToClipboard()">Copy</button> 
                <div class="desc-shortcode">Here is the shortcode you can copy and place anywhere.</div>        
            </div>
        </form>
        <script>
        function copyToClipboard() {
          var copyText = document.getElementById("form_shortcode");
          copyText.select();
          copyText.setSelectionRange(0, 99999); 
          navigator.clipboard.writeText(copyText.value);
          alert("Copied the text: " + copyText.value);
        }
        </script>
    </div>
<?php }


//Shortcode for a portfolio
function portfolio_custom_shortcode() {
    ob_start();
    
   $cat_args = array(
    'order'      => 'desc',
    'hide_empty' => true,
    );
 
    $portfolio_categories = get_terms( 'portfolio_category', $cat_args );
    ?> 
    <div class="homeportfolio-lists container">
        <ul class="tabs">
            <?php 
            $i = 1;
            foreach ($portfolio_categories as $portfolio_category) {

                $class = ($i == 1) ? "current" : "";
                 ?>
                <li data-cat="<?php echo $portfolio_category->term_id; ?>" class="tab-link <?php echo $class; ?>" data-tab="cat-<?php echo $i; ?>"><?php echo $portfolio_category->name; ?></li>
            <?php $i++;} ?>
        </ul>
        <?php 
        $j = 1;
        foreach ($portfolio_categories as $portfolio_category) {
            $args = array(
                'post_type'      => 'portfolio',
                'order'         => 'asc',
                'posts_per_page' => 4,
                'tax_query' => array(
                    array(
                        'taxonomy' => 'portfolio_category',
                        'field'    => 'slug',
                        'terms'    => $portfolio_category->name
                    )
                )   
            );
            $class = ($j == 1) ? "current" : "";
            $portfolio_lists = get_posts( $args );
            ?>
            <div id="cat-<?php echo $j; ?>" class="tab-content <?php echo $class?>">
                <div class="portfolio-lists">
                <?php 
                foreach ($portfolio_lists as $portfolio_list) {
                    $portfolio_id = $portfolio_list->ID;
                    $portfolio_img =  wp_get_attachment_url( get_post_thumbnail_id($portfolio_id), 'thumbnail' ); 

                    ?>
                    <div class="portfolio-item">
                        <a href="<?php echo get_permalink($portfolio_id); ?>"><img class="portfolio-img" src="<?php echo $portfolio_img; ?>" alt="portfolio" /></a>
                        <h4><strong><?php echo $portfolio_list->post_title ?></strong></h4>
                    </div>
                <?php } ?>
                </div>
                <div class="no-post-msg"></div>
            </div>
        <?php $j++;} ?>
        <div class="ajax-loader"><span class="pf-loader"></span></div>
        <div class="load-more-btn"><a id="load_more_btn" data-page="1" href="javascript:void(0)">Load More</a></div>
    </div>
    <?php    
    $output_string = ob_get_contents();
    ob_end_clean();
    return $output_string;
    wp_reset_postdata();

}
add_shortcode('portfolio-filter-lists', 'portfolio_custom_shortcode');

add_action('wp_ajax_nopriv_portfolio_listing', 'portfolio_listing');
add_action('wp_ajax_portfolio_listing', 'portfolio_listing');
function portfolio_listing(){
    global $wpdb;
    $success = $postCount =  0;
    $page = $_REQUEST['page']?$_REQUEST['page']:'0';
    $cat_id = $_REQUEST['cat_id']?$_REQUEST['cat_id']:'0';
    
    $per_page = 4;
    if($page){
      $paged = $page + 1;
    }

    $args = array(
        'post_type'      => 'portfolio',
        'post_status' => 'publish',
        'order'         => 'ASC',
        'posts_per_page' => $per_page,
        'paged'    => $paged,
        'tax_query' => array(
            array(
                'taxonomy' => 'portfolio_category',
                'field'    => 'term_id',
                'terms'    => $cat_id
            )
        )   
    );
    $portfolio_lists = get_posts( $args ); 
    $postCount = count($portfolio_lists);
    $total_post = ceil($postCount/$per_page);
    
    $html = '';
    if($postCount > 0 ){
        $success = 1;
        foreach ($portfolio_lists as $portfolio_list) {
            $portfolio_id = $portfolio_list->ID;
            $portfolio_img =  wp_get_attachment_url( get_post_thumbnail_id($portfolio_id), 'thumbnail' ); 
        $html  .= '<div class="portfolio-item">';
            $html  .= '<a href="'.get_permalink($portfolio_id).'"><img class="portfolio-img" src="'.$portfolio_img.'" alt="portfolio" /></a>
                <h4><strong>'.$portfolio_list->post_title.'</strong></h4>';
        $html  .=  '</div>';
        $html  .=  '<script>
                        jQuery(document).ready(function($){
                            MatchHeight();
                        });
                    </script>';
        }
    }else{
        $success = 0;
    }
    
    if($success == 1 && $postCount > 0){
      $output['type'] = 'success';
    }else{
      $output['type'] = 'failed';
    } 

    if($total_post <= $paged ){
        $output['loadmore'] = 'yes';
    }else{
        $output['loadmore'] = 'no';
    } 
    $output['html'] = $html;
    $output['page'] = $paged;
    echo json_encode($output);
    exit();
}



add_filter( 'archive_template', 'get_custom_post_type_template' );
 
function get_custom_post_type_template( $archive_template ) {
     global $post;
 
     if ( is_post_type_archive ( 'portfolio' ) ) {
          $archive_template = dirname( __FILE__ ) . '/archive-portfolio.php';
     }
     return $archive_template;
}