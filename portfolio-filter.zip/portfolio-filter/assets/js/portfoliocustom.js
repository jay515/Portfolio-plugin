jQuery(document).ready(function($){
  MatchHeight();
  $('ul.tabs li').click(function(){
      var tab_id = $(this).attr('data-tab');

      $("#load_more_btn").attr("data-page",1);
      jQuery("#load_more_btn").show();
      jQuery(".no-post-msg").hide();
      $( ".tab-content.current .portfolio-item" ).slice(4).remove();

      $('ul.tabs li').removeClass('current');
      $('.tab-content').removeClass('current');

      $(this).addClass('current');
      $("#"+tab_id).addClass('current');
      MatchHeight();
  })

});


function MatchHeight() {
  jQuery('.portfolio-img').matchHeight({});
  jQuery('.portfolio-item').matchHeight({});
}

jQuery(window).resize(function(){
    MatchHeight(); 
});

jQuery(function($){
    jQuery("#load_more_btn").on('click',function(){
        var page = jQuery(this).attr("data-page");
        var cat_id = jQuery('.tab-link.current').attr("data-cat");
         
        jQuery.ajax({
             type : "POST",
             url : frontend_ajax.ajaxurl,
             data : {action: "portfolio_listing", page : page,cat_id:cat_id},
             success: function(response) {
                jQuery(".pf-loader").show();
                var response = JSON.parse(response);
                if(response.type == "success"){
                  if(response.loadmore == "yes"){
                    var paged = response.page;
                    jQuery(".tab-content.current .portfolio-lists").append(response.html); 
                    var page_num =  jQuery("#load_more_btn").attr( "data-page");
                    jQuery("#load_more_btn").attr('data-page', paged);
                    jQuery(".pf-loader").hide();
                  }else{
                    jQuery(".tab-content.current .no-post-msg").html('No More Portfolio Found'); 
                    jQuery(".tab-content.current .no-post-msg").show();
                    jQuery("#load_more_btn").hide();
                    jQuery(".pf-loader").hide();
                  }        
                }else{
                  jQuery(".tab-content.current .no-post-msg").html('No More Portfolio Found'); 
                  jQuery(".tab-content.current .no-post-msg").show();
                  jQuery("#load_more_btn").hide();
                  jQuery(".pf-loader").hide();
                } 
             }
          });   
     });
});